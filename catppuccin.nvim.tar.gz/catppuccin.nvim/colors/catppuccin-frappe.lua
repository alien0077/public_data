require("catppuccin").load "frappe"

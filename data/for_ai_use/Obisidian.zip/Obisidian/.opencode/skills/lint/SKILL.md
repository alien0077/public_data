# lint — 知識庫健康檢查技能

## 觸發方式
當使用者說 `/lint` 時啟動。

## 檢查項目

### 1. 孤島頁面
掃描所有 wiki 頁面，找出沒有被任何其他頁面雙向連結的頁面。

### 2. 死鏈
找出 wiki 頁面中連結了但不存在的 `[[PageName]]`。

### 3. 未註冊頁面
- 存在但未列在 `wiki/index.md` 中的頁面
- `wiki/index.md` 有列但檔案不存在的頁面

### 4. 類型化連結檢查
確認所有 wikilink 是否使用了 `@` 語法標記關係類型：
- 缺少類型標記的連結應標記為「建議加強」
- 常見類型：`@supersedes`, `@contradicts`, `@supports`, `@causes`, `@references`, `@evolution_of`, `@prerequisite_for`

### 5. 知識衝突掃描
- 檢查各頁面中是否存在 `## 知識衝突` 區塊
- 標記未被記錄的矛盾

### 6. YAML Frontmatter 驗證
確認每個頁面包含：
- `title`
- `type`（concept/entity/source/synthesis）
- `tags`
- `last_updated`

### 7. QMD 索引健康
使用 `wiki` MCP 工具的 `status` 檢查索引狀態。

## 回報格式
```markdown
## lint 結果 [YYYY-MM-DD]

### ✅ 通過
- ...

### ⚠️ 警告
- ...

### ❌ 問題
- ...

### 📊 統計
- 總頁數：
- 孤島：
- 死鏈：
- 索引狀態：
```

# ingest — 原始資料編譯技能

## 觸發方式
當使用者說 `/ingest <路徑>` 或提到「攝入/消化這份資料」時啟動。

## 流程

### 1. 讀取原始資料
- 從 `raw/` 目錄讀取指定檔案（支援 `.md`, `.pdf`, `.txt`）
- 如果檔案是 PDF，先嘗試讀取文字內容
- 如果是網頁剪藏 Markdown，注意 obsidian-web-clipper 格式

### 2. 與使用者討論
- 簡要總結檔案核心內容
- 詢問使用者想強調的重點或角度
- 確認是否有現有 wiki 頁面需要更新

### 3. 讀取相關現有頁面
- 使用 QMD 的 `query` 工具搜尋相關概念
- 讀取 `wiki/index.md` 了解全局
- 讀取可能受影響的現有 wiki 頁面

### 4. 建立來源摘要
在 `wiki/sources/` 建立摘要頁面：
```yaml
---
title: "摘要-{slug}"
type: source
tags: [關鍵標籤]
sources: [raw/相對路徑]
last_updated: YYYY-MM-DD
---
```

### 5. 更新或建立實體/概念頁面
- 在 `wiki/entities/` 更新相關實體頁面
- 在 `wiki/concepts/` 更新相關概念頁面
- 所有 wikilink 必須使用 `@` 類型化連結語法

### 6. 更新 index.md
將新頁面加入 `wiki/index.md` 的對應分類

### 7. 記錄操作到 log.md
在 `wiki/log.md` 追加操作記錄

### 8. 歸檔原始檔
將原始檔案移動到 `raw/09-archive/`

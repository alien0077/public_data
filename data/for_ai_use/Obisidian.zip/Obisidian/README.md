# LLM Wiki 知識庫

基於 [Karpathy 的 LLM Wiki 理念](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) 構建的個人 AI 知識庫。

## 目錄結構

```
Obisidian/
├── raw/                  ← 原始素材（唯讀）
│   ├── 01-articles/      ← 網頁剪藏
│   ├── 02-papers/        ← 論文/報告
│   ├── 03-transcripts/   ← 逐字稿
│   └── 09-archive/       ← 已歸檔
├── wiki/                 ← 知識庫（LLM 編譯）
│   ├── index.md          ← 總目錄
│   ├── log.md            ← 操作日誌
│   ├── concepts/         ← 概念、框架
│   ├── entities/         ← 人物、工具、產品
│   ├── sources/          ← 來源摘要
│   └── syntheses/        ← 綜合分析
├── assets/               ← 媒體檔案
├── .opencode/skills/     ← OpenCode 技能
│   ├── ingest/SKILL.md
│   ├── query/SKILL.md
│   └── lint/SKILL.md
└── AGENTS.md             ← 全域心智規範
```

## 核心特色

- **類型化連結**：所有 `[[wikilink]]` 使用 `@supersedes`、`@contradicts`、`@supports` 等語意標記
- **QMD 搜尋**：透過全域 MCP 從任何專案存取，支援混合搜尋（BM25 + 向量 + 重排序）
- **Obsidian 整合**：圖形視圖顯示類型化關係，Dataview 可查詢 YAML frontmatter

## 常用命令

- `/ingest <路徑>` — 攝入原始資料到知識庫
- `/query <問題>` — 查詢知識庫
- `/lint` — 健康檢查

## 外部專案存取

已在 `~/.config/opencode/opencode.jsonc` 註冊 `wiki` MCP 工具，任何 OpenCode 專案皆可透過此工具搜尋和讀取本知識庫。

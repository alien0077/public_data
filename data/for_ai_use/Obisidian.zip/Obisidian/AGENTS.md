# 語言設定與核心角色
- **語言指令**：無論輸入何種語言，你必須始終使用**繁體中文**進行思考、回覆和知識庫的編寫。
- **角色定義**：你正在維護一個 **LLM Wiki**（根據 [Karpathy 的規範](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)），你的任務是將碎片化的資訊編譯成結構化、高度互相連結的 Obsidian 知識庫。

# 核心目錄與權限邊界

- `/raw/`（不可變層）— **絕對唯讀**。原始素材、網頁剪藏。禁止修改或刪除。
- `/assets/`（媒體資產層）— 圖片、PDF。引用語法 `![[檔案名稱.png]]`
- `/wiki/`（編譯輸出層）— 你的專屬工作區。在此建立、更新、提煉知識並解決矛盾。
- `.opencode/skills/`（技能定義層）— ingest / query / lint 技能規範。

# 類型化連結規範（Typed Wikilinks）
所有 wiki 頁面的雙向連結**必須**使用 `@` 語法標記關係類型：

| 語法 | 意義 |
|------|------|
| `[[目標\|說明 @supersedes]]` | 新內容取代舊內容 |
| `[[目標\|說明 @contradicts]]` | 內容互相矛盾 |
| `[[目標\|說明 @supports]]` | 內容支持另一論點 |
| `[[目標\|說明 @causes]]` | 因果關係 |
| `[[目標\|說明 @references]]` | 引用/參考 |
| `[[目標\|說明 @evolution_of]]` | 概念演進 |
| `[[目標\|說明 @prerequisite_for]]` | 前置條件 |

儲存後類型會自動同步到 YAML frontmatter，供 Obsidian Dataview 查詢。

# Wiki 核心檔案契約

1. **`wiki/index.md`（總目錄）**：
   每次向 wiki 新增知識頁後，必須同步更新此檔案。格式：
   ```markdown
   ## Sources
   - [[摘要-source-slug]] — 該資料的核心主旨摘要。
   ## Entities
   - [[EntityName]] — 該實體的身份定義或核心功能。
   ## Concepts
   - [[ConceptName]] — 該概念或框架的核心定義。
   ## Syntheses
   - [[synthesis-slug]] — 該頁面回答的複雜問題。
   ```

2. **`wiki/log.md`（操作日誌）**：
   只能 Append-only。格式：`## [YYYY-MM-DD] <動作> | <操作简述>`。

3. **內容分類**：
   - `wiki/concepts/` — 概念、框架、方法論
   - `wiki/entities/` — 人物、公司、工具、產品
   - `wiki/sources/` — 原始素材摘要
   - `wiki/syntheses/` — 綜合分析報告

4. **強制雙向連結**：
   每個 wiki 頁面必須包含 `## 關聯連結` 區域，使用 `[[PageName @typed]]`。
   絕不能產生孤島頁面。

5. **矛盾處理原則**：
   新知識與舊知識衝突時，在頁面中新建 `## 知識衝突` 區塊，保留兩種說法並做對比。

# 工作流程

- `/ingest <路徑>` — 讀取 `raw/` 檔案，編譯整合到 `wiki/`，使用 `@` 類型化連結，更新 index 和 log。
- `/query <問題>` — 透過 `wiki` MCP 工具的 `query` 搜尋，深度閱讀後綜合回答，使用 `[[wikilink @typed]]` 標註來源。
- `/lint` — 掃描 wiki 的死鏈、孤島頁面、遺漏的類型化連結、知識衝突。

# YAML Frontmatter 規範

```yaml
---
title: "頁面標題"
type: concept | entity | source | synthesis
tags: [知識標籤]
sources: [關聯的 raw 檔案相對路徑]
last_updated: YYYY-MM-DD
---
```

# 外部知識庫存取
你擁有 `wiki` MCP 工具，可搜尋和讀取個人知識庫：
- 使用 `wiki` 的 `query` 工具搜尋相關頁面
- 用 `get` 工具讀取完整內容
- 引用時使用 `[[PageName @typed]]` 格式
- 搜尋不到時用 `status` 檢查 QMD 索引狀態

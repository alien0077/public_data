# Wiki 操作日誌

---

## [2026-05-28] init | 初始化知識庫
- **動作**: 清空模板內容，重建骨架
- **工具**: Obsidian 1.12.7 / QMD 2.5.2 / OpenCode
- **技能**: `.opencode/skills/{ingest,query,lint}/SKILL.md`
- **類型化連結**: 啟用 `@` 語法（supersedes / contradicts / supports / causes / references / evolution_of / prerequisite_for）
- **外部存取**: QMD MCP 已註冊至全域 OpenCode 設定
- **狀態**: 空知識庫待填充

---

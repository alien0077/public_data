---
name: ios-ui-debugging
description: Use when debugging iOS UI issues — misplaced views, invisible/overlapping elements, Auto Layout conflicts, constraint ambiguity, or unexpected layout behavior in UIKit Swift projects.
---

# iOS UI Debugging with LLDB

## Overview
使用 LLDB 文字指令進行 iOS UI 除錯，讓 AI 可以直接讀取 view hierarchy、constraints 等資訊並分析問題，無需依賴視覺化工具。

## Prerequisites: Install Chisel (Facebook)
```bash
brew install chisel
echo "command script import /usr/local/share/chisel/Chisel/Chisel.py" >> ~/.lldbinit
```
重啟 Xcode 後生效。Chisel 提供 `pviews`、`pvc`、`border` 等便捷指令。

## Quick Reference

### View Hierarchy
| Command | Description |
|---------|-------------|
| `po [[UIApplication sharedApplication] keyWindow] _recursiveDescription` | Full view tree from keyWindow |
| `po [[[UIWindow keyWindow] rootViewController] _printHierarchy]` | Controller hierarchy |
| `pviews` (Chisel) | Concise view hierarchy |
| `pvc` (Chisel) | Concise controller hierarchy |

### Select & Visualize Views
| Command | Description |
|---------|-------------|
| `expr UIView *$v = (UIView *)targetView` | Store view in variable for reuse |
| `border $v` / `border $v 3 #FF0000` (Chisel) | Highlight view boundary |
| `unborder $v` (Chisel) | Remove highlight |
| `po [view recursiveDescription]` | Subtree from a specific view |

### Auto Layout
| Command | Description |
|---------|-------------|
| `po [[UIWindow keyWindow] _autolayoutTrace]` | Layout debug — marks AMBIGUOUS / UNSATISFIABLE |
| `po [view constraints]` | All constraints on this view |
| `po [view _autolayoutTrace]` | Per-view layout trace |

### Runtime Property Modification
| Command | Description |
|---------|-------------|
| `expr [view setBackgroundColor:[UIColor redColor]]` | Temporarily color a view |
| `expr [view setHidden:NO]` | Force-show a view |
| `expr [view setAlpha:1.0]` | Reset opacity |
| `expr [view setFrame:CGRectMake(x, y, w, h)]` | Adjust frame |
| `po [view backgroundColor]` | Read property value |

## SOP: Common Scenarios

### View not visible
```
po [[UIApplication sharedApplication] keyWindow] _recursiveDescription
```
Check: is the view in hierarchy? Is frame zero? Is hidden=YES or alpha=0? Is it behind another view?

### Auto Layout conflict / ambiguity
```
po [[[UIWindow keyWindow] rootViewController] _printHierarchy]
po [[UIWindow keyWindow] _autolayoutTrace]
```
`_autolayoutTrace` flags `AMBIGUOUS LAYOUT` and `Unable to simultaneously satisfy constraints`.

### Overlapping or misplaced views
```
expr UIView *$v1 = (UIView *)firstView
expr UIView *$v2 = (UIView *)secondView
border $v1
border $v2
```
Visualize both view frames to see the actual overlap.

## When LLDB Isn't Enough

### FLEX (user-interactive)
Ask user to integrate FLEX and manually inspect:
1. Add `FLEX` via SPM/CocoaPods; init in AppDelegate/SceneDelegate
2. Shake device or tap floating button to open
3. Tap any UI element to inspect properties

### Xcode Debug View Hierarchy (visual)
Ask user to:
1. Run app and trigger the screen
2. Click the Debug View Hierarchy button (cube icon) in Xcode debug bar
3. Share screenshot or describe the 3D hierarchy view

## Edge Cases
- **SwiftUI**: LLDB `_recursiveDescription` doesn't apply to SwiftUI views. Use Xcode Debug View Hierarchy instead.
- **Simulator vs device**: All LLDB commands work on both.
- **No LLDB output**: Ensure breakpoint is paused on main thread; check Xcode console (not system log).
- **Chisel not found**: Verify `~/.lldbinit` is sourced (`lldb --source ~/.lldbinit`), or fall back to native `_recursiveDescription`.

import subprocess
import time
import json
import os
import signal
import sys
from pathlib import Path

PROJECT_ROOT = "/Users/alien/Desktop/TWStockTracker"
PORT = 8765
TRANSACTIONS_PATH = os.path.join(PROJECT_ROOT, "合庫", "2026-05-25_transactions.json")
WEB_INDEX_PATH = "/temp_repo/web/index.html"
BASE_URL = f"http://localhost:{PORT}"

server_process = None

def start_server():
    global server_process
    server_process = subprocess.Popen(
        ["python3", "-m", "http.server", str(PORT), "--directory", PROJECT_ROOT],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    print(f"✅ HTTP Server started on http://localhost:{PORT}")
    time.sleep(1.5)

def stop_server():
    global server_process
    if server_process:
        server_process.terminate()
        server_process.wait()
        print("🛑 HTTP Server stopped.")

def load_transactions():
    with open(TRANSACTIONS_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    trades = data.get("normalizedTrades", [])
    print(f"📄 Loaded {len(trades)} trades from {TRANSACTIONS_PATH}")
    return trades

def build_import_script(trades):
    js_trades = json.dumps(trades, ensure_ascii=False)
    return f"""
        (async () => {{
            // Clear old database
            const delReq = indexedDB.deleteDatabase('TWStockTrackerDB');
            await new Promise((resolve) => {{ delReq.onsuccess = () => resolve(); delReq.onerror = () => resolve(); }});

            // Open fresh DB
            const db = await new Promise((resolve, reject) => {{
                const req = indexedDB.open('TWStockTrackerDB', 1);
                req.onupgradeneeded = (e) => {{
                    const d = e.target.result;
                    if (!d.objectStoreNames.contains('trades')) {{
                        d.createObjectStore('trades', {{ keyPath: 'id', autoIncrement: true }});
                    }}
                }};
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            }});

            // Import normalized trades
            const trades = {js_trades};
            const tx = db.transaction('trades', 'readwrite');
            const store = tx.objectStore('trades');

            for (const t of trades) {{
                store.put({{
                    symbol: t.symbol,
                    name: t.stockName,
                    date: t.tradeDate ? t.tradeDate.split('T')[0] : '',
                    side: t.side === '買進' ? 'buy' : (t.side === '賣出' ? 'sell' : t.side),
                    price: t.price,
                    shares: t.quantity,
                    quantity: t.quantity,
                    fee: t.fee || 0,
                    tax: t.tax || 0,
                    netAmount: t.netAmount || 0,
                    timestamp: Date.now()
                }});
            }}

            await new Promise((resolve, reject) => {{
                tx.oncomplete = () => resolve();
                tx.onerror = () => reject(tx.error);
            }});

            db.close();
            console.log(`✅ Imported ${{trades.length}} trades into IndexedDB`);
            return trades.length;
        }})()
    """

def debug():
    from playwright.sync_api import sync_playwright

    trades = load_transactions()
    import_script = build_import_script(trades)

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=["--start-maximized"]
        )
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            no_viewport=True
        )
        page = context.new_page()

        page.on("console", lambda msg: print(f"  [Console {msg.type}] {msg.text}"))
        page.on("pageerror", lambda err: print(f"  [❌ JS Error] {err}"))

        url = f"{BASE_URL}{WEB_INDEX_PATH}"
        print(f"🌐 Navigating to {url} ...")
        page.goto(url, wait_until="networkidle", timeout=30000)
        print(f"📄 Page title: {page.title()}")

        # Bypass auth with password "test"
        print("🔑 Setting auth bypass (password: test)...")
        page.evaluate("localStorage.setItem('twstock_secret', 'test')")

        # Import transactions into IndexedDB
        print("📥 Importing transactions into IndexedDB...")
        count = page.evaluate(import_script)
        print(f"✅ Imported {count} trades")

        # Reload to trigger app render with auth + data
        print("🔄 Reloading page...")
        page.reload(wait_until="networkidle", timeout=30000)

        print("\n" + "=" * 60)
        print("🔍 Browser is now running in HEADED mode.")
        print(f"   URL: {url}")
        print("   Password: test")
        print("   Imported trades from 合庫/2026-05-25_transactions.json")
        print("   Close the browser window to stop debugging.")
        print("=" * 60)

        # Wait until browser closes
        page.wait_for_event("close", timeout=0)

        browser.close()
        print("👋 Browser closed. Debug session ended.")

if __name__ == "__main__":
    try:
        start_server()
        debug()
    except KeyboardInterrupt:
        print("\n⚠️ Interrupted by user.")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        stop_server()

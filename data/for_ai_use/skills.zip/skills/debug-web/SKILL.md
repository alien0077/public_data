---
name: debug-web
description: Debug web app using Webwright/Playwright. Starts a local HTTP server (not 8000), imports transactions data from 合庫 JSON, and launches headed Playwright with password auth bypass. Activate when user says "debug web" or "debug web app".
allowed-tools: Bash, Read, Write, Edit, Glob, Grep
---

# Debug Web — Webwright-style Debugging

當你說「debug web」時，啟動本技能。它使用 Webwright 的 code-as-action 風格，在本地瀏覽器中載入網頁應用程式，注入合庫交易資料，讓你以開發者角度觀察頁面行為。

## 工作流程

### 1️⃣ 啟動本地 HTTP Server

在專案根目錄啟動 Python HTTP 伺服器，**不使用 8000 port**：

```bash
python3 -m http.server 8765 --directory /Users/alien/Desktop/TWStockTracker
```

確認伺服器運作後再進行下一步。

### 2️⃣ 執行 Playwright Debug Script

執行附帶的腳本 `scripts/debug_web.py`，它會：

1. 啟動 Playwright Chromium（**headed** 模式，讓你可觀察）
2. 導航至 `http://localhost:8765/temp_repo/web/index.html`
3. 使用密碼 `test` 繞過認證（設 `localStorage.twstock_secret = 'test'`）
4. 從 `@合庫/2026-05-25_transactions.json` 讀取交易資料
5. 將交易資料寫入 IndexedDB (`trades` store)
6. 重新載入頁面，觸發 Dashboard/Portfolio 重新渲染
7. 依需求截圖或執行 JS 偵錯

```bash
python3 .agents/skills/debug-web/scripts/debug_web.py
```

### 3️⃣ 偵錯與驗證

觀察瀏覽器中的頁面行為：
- **Dashboard** 是否正確顯示持股摘要
- **Portfolio** (`router.switchPage('portfolio')`) 是否反映匯入的交易
- **Console** 訊息是否有錯誤
- **Network** 請求是否正確

### 4️⃣ 清理

關閉瀏覽器後，腳本會自動終止 HTTP 伺服器。

## 注意事項

- 密碼 `test` 在本地模式自動生效（因 Cloudflare Worker 連線失敗會 fallback 允許任何金鑰）
- 交易資料從 `合庫/2026-05-25_transactions.json` 讀取，格式為 `normalizedTrades`
- 使用 headed Chromium 瀏覽器，方便你觀察頁面行為
- 每次執行會先清空 IndexedDB 再重新匯入

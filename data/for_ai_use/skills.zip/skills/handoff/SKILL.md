---
name: handoff
description: 在 context 接近容量上限、完成階段性工作、或被動指令時，產出標準化的 handoff.md 讓新 session 接續。新 session 啟動時自動偵測 handoff.md 並恢復進度。
allowed-tools: Bash, Read, Write, Edit, Glob, Grep
---

# Handoff Skill

## 角色
你是 session 間的橋樑。當 context 過長、階段性工作完成、或收到 `/handoff` 指令時，產出 `handoff.md`。新 session 啟動時，若偵測到 `handoff.md`，讀取並恢復工作。

---

## 產出 handoff（當前 session 用）

### 觸發時機

| 時機 | 觸發方式 |
|------|----------|
| **主動感知** | 意識到 context 明顯過長、頻繁遺忘早期對話時，**主動詢問**是否要產 handoff |
| **被動指令** | 使用者說 `/handoff`、「做交接」、「產交接檔」時立即執行 |
| **階段完成** | 完成一個完整 task 後，**主動詢問**是否要產 handoff（特別是有後續依賴工作時） |
| **異常中斷** | 使用者關閉 terminal / 超時前，若來得及就自動產出 |

### 產出位置

寫入專案根目錄：`<project_root>/handoff.md`

若已存在則更名舊檔為 `handoff_<timestamp>.md` 再寫新檔。

### 內容結構

必須包含以下章節，遵循 `reference/handoff_template.md`：

1. **Header** — Session Tag、日期、專案路徑
2. **Session 摘要** — 做了什麼、用了多少 tool calls（概估）
3. **已完成變更** — 每個修改過的檔案 + 行號範圍 + 變更摘要
4. **進行中工作** — 未完成的項目、卡住的問題、待確認事項
5. **剩餘待辦** — 明確的 next steps（可執行的指令）
6. **關鍵發現** — bug 根因、API 行為、架構決策等
7. **技術脈絡** — 常用指令、專案結構重點、相依性
8. **恢復指令** — 新 session 的第一個動作

---

## 恢復 handoff（新 session 用）

### 觸發時機

新 session 啟動時，**第一步先檢查專案根目錄是否有 `handoff.md`**。

### 恢復流程

```
1. 偵測到 handoff.md → 讀取完整內容
2. 驗證 Session Tag 是否與上次一致（比對 git log 最新 commit）
3. 執行「恢復指令」區塊中的第一步
4. 完成後詢問使用者是否標記 handoff 為已處理
```

### 標記已處理

```bash
mv handoff.md handoff_<session_tag>_done.md
```

保留 `handoff_*_done.md` 作為歷史紀錄，不清除。

---

## 規則

- 每次產出前先 `git status` 確認當前工作目錄狀態
- 產出時檢查未 commit 的變更，在摘要中註明
- 若使用者在對話中途要求 handoff，保留所有已完成工作的檔名與行號
- 路徑使用絕對路徑（避免新 session 的 cwd 不同）
- 不主動刪除舊 handoff 檔案
- 恢復完成後務必告知使用者「已從 handoff.md 恢復工作」

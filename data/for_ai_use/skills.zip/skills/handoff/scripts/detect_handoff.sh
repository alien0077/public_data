#!/bin/bash
# detect_handoff.sh — 檢查專案根目錄是否有 handoff.md，回傳狀態
# 供新 session 的 agent 快速判斷是否需要恢復

HANDOFF_FILE=""
PROJECT_ROOT=""

# Try common locations
for dir in "$PWD" "/Users/alien/Desktop/TWStockTracker"; do
    if [ -f "$dir/handoff.md" ]; then
        HANDOFF_FILE="$dir/handoff.md"
        PROJECT_ROOT="$dir"
        break
    fi
done

if [ -z "$HANDOFF_FILE" ]; then
    echo "NO_HANDOFF"
    exit 0
fi

SESSION_TAG=$(head -5 "$HANDOFF_FILE" | grep 'session_tag' | cut -d: -f2 | xargs)
SUMMARY=$(grep -A2 'Session 摘要' "$HANDOFF_FILE" | tail -1 | sed 's/^[[:space:]]*//; s/<!--.*-->//' | xargs)
TODO_COUNT=$(grep -c '\- \[ \]' "$HANDOFF_FILE")
FILE_COUNT=$(grep -c '^| \`' "$HANDOFF_FILE")

echo "HANDOFF_DETECTED"
echo "SESSION_TAG=$SESSION_TAG"
echo "PROJECT_ROOT=$PROJECT_ROOT"
echo "REMAINING_TASKS=$TODO_COUNT"
echo "MODIFIED_FILES=$FILE_COUNT"
echo "SUMMARY=$SUMMARY"
